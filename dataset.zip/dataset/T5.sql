WITH Product_IR AS (
    SELECT 
        product_name,
        category,
        (SUM(incremental_revenue) / SUM(revenue_before_promotion)) * 100 AS ir_percentage
    FROM 
        retail_events_db.final
    GROUP BY 
        product_name, category
)

SELECT 
    product_name,
    category,
    ir_percentage
FROM 
    Product_IR
ORDER BY 
    ir_percentage DESC
LIMIT 5;
