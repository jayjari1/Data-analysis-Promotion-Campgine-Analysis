WITH Diwali_Campaign AS (
    SELECT 
        category,
        SUM(QA) AS total_quantity_after_promo,
        SUM(QB) AS total_quantity_before_promo
    FROM 
        retail_events_db.final1
    WHERE 
        campaign_name = 'Diwali'
    GROUP BY 
        category
)

SELECT 
    category,
    ((total_quantity_after_promo - total_quantity_before_promo) / total_quantity_before_promo) * 100 AS isu_percentage,
    RANK() OVER (ORDER BY ((total_quantity_after_promo - total_quantity_before_promo) / total_quantity_before_promo) DESC) AS rank_order
FROM 
    Diwali_Campaign;
