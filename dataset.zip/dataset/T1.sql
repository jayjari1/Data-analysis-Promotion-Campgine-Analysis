SELECT DISTINCT product_name, promo_type, base_price
FROM retail_events_db.final
WHERE base_price > 500
AND promo_type = 'BOGOF';

