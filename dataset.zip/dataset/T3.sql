SELECT 
    campaign_name,
    SUM(revenue_before_promotion) / 1000000.0 AS total_revenue_before_promotion_in_millions,
    SUM(revenue_after_promotion) / 1000000.0 AS total_revenue_after_promotion_in_millions
FROM 
    retail_events_db.final
GROUP BY 
    campaign_name;
