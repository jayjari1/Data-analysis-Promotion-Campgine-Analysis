SELECT city, COUNT(DISTINCT store_id) AS store_count
FROM retail_events_db.final
GROUP BY city
ORDER BY store_count DESC;
